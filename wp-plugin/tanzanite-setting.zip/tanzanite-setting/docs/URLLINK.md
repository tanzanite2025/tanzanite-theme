# URLLink - URL 管理与重写

**功能模块**: URLLink  
**权限要求**: `manage_options`  
**集成方式**: 已集成到 Tanzanite Settings

---

## 📋 功能概述

URLLink 是一个强大的 URL 管理工具，允许你自定义文章、页面和商品的 URL 结构，创建 URL 目录树，管理 URL 重定向，并支持批量操作。

---

## ✨ 核心功能

### 1. URL 目录管理

#### 目录树结构

**功能**:
- 创建层级目录结构
- 为每个目录设置路径别名（path_slug）
- 将内容附加到目录
- 目录重命名和删除

**使用场景**:
```
products/          # 商品目录
  ├── phones/      # 手机子目录
  ├── laptops/     # 笔记本子目录
  └── accessories/ # 配件子目录

guides/            # 指南目录
  ├── en/          # 英文指南
  └── zh/          # 中文指南
```

---

#### 创建目录

**步骤**:
1. 在左侧"URL 目录树"面板
2. 填写目录名称（例如：商品）
3. 填写路径别名（例如：products）
4. 选择父目录（可选，默认顶层）
5. 点击"新建目录"

**路径别名规则**:
- 使用小写字母和连字符
- 支持多级路径（例如：guides/fr）
- 不要使用特殊字符
- 避免与 WordPress 保留路径冲突

---

#### 附加内容到目录

**方法 1：在目录树中附加**
1. 找到目标目录
2. 在"将页面附加到该目录"输入框中粘贴页面 URL
3. 点击"确定并同步"

**方法 2：在内容列表中设置**
1. 在右侧内容列表找到目标内容
2. 在"Custom Path"列填写完整路径
3. 点击"Save"

**示例**:
```
目录: products (path_slug: products)
内容: iPhone 15 Pro (post_name: iphone-15-pro)
结果 URL: /products/iphone-15-pro
```

---

### 2. 自定义 URL 路径

#### 单个内容设置

**Custom Path 字段**:
- 完整自定义路径
- 支持变量替换
- 自动保存旧路径用于重定向

**变量支持**:
```
{postname}  - 文章别名
{sku}       - 商品 SKU（需启用）
{id}        - 文章 ID
{year}      - 发布年份
{month}     - 发布月份
{day}       - 发布日期
```

**示例**:
```
原始 URL: /iphone-15-pro/
自定义 URL: /products/phones/iphone-15-pro/
模板: products/phones/{postname}
```

---

#### 批量设置

**批量应用到目录**:
1. 勾选要操作的内容
2. 选择目标目录
3. 选择策略：
   - **replace**: 完全替换路径
   - **prefix**: 添加前缀
4. 填写旧前缀（可选，用于替换）
5. 勾选"干跑预览"查看效果
6. 点击"执行"

**策略说明**:

**Replace 策略**:
```
目录: products/phones
内容: iphone-15-pro
结果: products/phones/iphone-15-pro
```

**Prefix 策略**:
```
目录: products
旧前缀: shop
原路径: shop/iphone-15-pro
结果: products/iphone-15-pro
```

---

### 3. 额外重定向

#### Extra Redirects 字段

**功能**:
- 为同一内容设置多个旧 URL
- 自动 301 重定向到当前 URL
- 每行一个 URL

**使用场景**:
```
当前 URL: /products/iphone-15-pro/

额外重定向:
/old-shop/iphone-15/
/phones/iphone15pro/
/mobile/apple-iphone-15-pro/
```

**效果**:
- 访问任何旧 URL 都会自动重定向到当前 URL
- SEO 友好的 301 永久重定向
- 保留搜索引擎权重

---

### 4. 批量操作

#### 可用操作

**刷新列表**
- 重新加载内容列表
- 更新显示状态

**复制内容**
- 复制选中的内容
- 包含所有 meta 数据
- 自动标记为克隆
- 生成唯一的 URL

**移至回收站**
- 将选中内容移至回收站
- 可恢复

**彻底删除**
- 永久删除选中内容
- ⚠️ 不可恢复

**同步到 WordPress**
- 重建 URL 映射
- 刷新站点地图
- 通知 MyTheme SEO 更新

---

### 5. URL 映射管理

#### 映射机制

**自动映射**:
- 每次保存自定义路径时自动更新
- 存储在 `urllink_path_map` option
- 快速查找和重定向

**手动重建**:
- 点击"重建映射"按钮
- 扫描所有内容的自定义路径
- 重新生成完整映射表

---

## 🔧 高级功能

### 1. SKU 在 URL 中

**启用设置**:
```php
// 在 WordPress 设置中启用
update_option('urllink_enable_sku_in_url', 1);
```

**使用 SKU 变量**:
```
模板: products/{sku}-{postname}
SKU: IP15P-256-BLK
结果: products/IP15P-256-BLK-iphone-15-pro
```

---

### 2. 旧路径自动保存

**机制**:
- 修改 Custom Path 时自动保存旧路径
- 存储在 `_urllink_old_paths` meta
- 自动设置 301 重定向

**查看旧路径**:
```php
$old_paths = get_post_meta($post_id, '_urllink_old_paths', true);
// 返回数组：['old-path-1', 'old-path-2']
```

---

### 3. 克隆内容

**克隆标记**:
- 克隆的内容自动标记
- 显示"CLONED"徽章
- 记录原始内容 ID

**Meta 字段**:
```php
_urllink_cloned: 1
_urllink_cloned_from: 原始内容ID
```

---

## 💻 开发者接口

### 钩子和过滤器

#### 重建映射后
```php
add_action('urllink_maps_rebuilt', function() {
    // 映射重建完成
});
```

#### 与 MyTheme SEO 集成
```php
// URLLink 请求刷新站点地图
do_action('mytheme_seo_request_sitemap_rebuild', [
    'source' => 'urllink'
]);

// URLLink 请求刷新
do_action('mytheme_seo_refresh_after_urllink');
```

---

### 函数

#### 规范化路径
```php
function urllink_normalize_path($path) {
    return trim($path, '/');
}
```

#### 更新映射
```php
function urllink_update_map_for_post($post_id, $path) {
    $map = get_option('urllink_path_map', []);
    $norm = urllink_normalize_path($path);
    $map[$norm] = $post_id;
    update_option('urllink_path_map', $map);
}
```

#### 重建所有映射
```php
URLLink_Plugin::rebuild_maps();
```

---

## 🎯 使用场景

### 1. 多语言网站

**目录结构**:
```
/en/products/iphone-15-pro/
/zh/products/iphone-15-pro/
/fr/products/iphone-15-pro/
```

**设置**:
1. 创建语言目录：en, zh, fr
2. 将内容附加到对应语言目录
3. 使用 {postname} 保持一致性

---

### 2. 商品分类

**目录结构**:
```
/products/phones/
/products/laptops/
/products/accessories/
```

**批量操作**:
1. 创建分类目录
2. 批量选择商品
3. 应用到对应目录

---

### 3. SEO 优化

**URL 重构**:
```
旧 URL: /p=123
新 URL: /products/category/product-name/

旧 URL: /product/12345/
新 URL: /shop/product-name/
```

**保留 SEO**:
- 旧 URL 自动 301 重定向
- 搜索引擎权重保留
- 用户体验不受影响

---

### 4. 网站迁移

**从其他平台迁移**:
1. 导入内容到 WordPress
2. 在 Extra Redirects 添加旧 URL
3. 保持旧链接可访问
4. 逐步更新外部链接

---

## 📝 最佳实践

### 1. URL 设计原则

**简洁明了**:
```
✅ /products/iphone-15-pro/
❌ /category/products/subcategory/phones/apple/iphone-15-pro-256gb-black/
```

**使用连字符**:
```
✅ /iphone-15-pro/
❌ /iphone_15_pro/
❌ /iPhone15Pro/
```

**避免特殊字符**:
```
✅ /products/phone/
❌ /产品/手机/
❌ /products/phone%20case/
```

---

### 2. 目录规划

**层级不要太深**:
```
✅ /products/phones/iphone-15-pro/
❌ /shop/products/electronics/phones/smartphones/apple/iphone/15/pro/
```

**使用有意义的名称**:
```
✅ /products/
✅ /guides/
✅ /support/

❌ /cat1/
❌ /section-a/
❌ /misc/
```

---

### 3. 重定向管理

**定期清理**:
- 检查不再需要的重定向
- 删除过期的旧 URL
- 保持映射表精简

**测试重定向**:
- 访问旧 URL 确认跳转
- 检查 HTTP 状态码（应为 301）
- 验证目标 URL 正确

---

### 4. 性能优化

**映射表优化**:
- 定期重建映射
- 清理无效条目
- 使用对象缓存

**批量操作**:
- 大量内容时分批处理
- 使用干跑预览验证
- 完成后重建映射

---

## 🔍 故障排除

### Q: 自定义 URL 不生效？

**A**: 检查以下几点：
1. 是否点击了"Save"按钮
2. 是否重建了映射
3. 是否刷新了固定链接（设置 → 固定链接 → 保存）
4. 检查 .htaccess 文件权限

---

### Q: 重定向不工作？

**A**: 
1. 确认旧路径已保存到 Extra Redirects
2. 重建 URL 映射
3. 清除浏览器缓存
4. 检查服务器重写规则

---

### Q: 批量操作失败？

**A**:
1. 检查是否勾选了内容
2. 确认目录 path_slug 已设置
3. 使用干跑预览查看错误
4. 分批处理大量内容

---

### Q: 克隆内容 URL 冲突？

**A**:
- 克隆时自动添加 `-copy` 后缀
- 如果仍冲突，会添加数字后缀
- 手动修改 Custom Path 避免冲突

---

## 🗄️ 数据库

### 文章 Meta

| Meta Key | 说明 | 类型 |
|----------|------|------|
| `_urllink_path` | 自定义路径 | string |
| `_urllink_extra_redirects` | 额外重定向 | string (多行) |
| `_urllink_old_paths` | 旧路径列表 | array |
| `_urllink_cloned` | 是否克隆 | boolean |
| `_urllink_cloned_from` | 克隆源 ID | integer |

### Term Meta

| Meta Key | 说明 | 类型 |
|----------|------|------|
| `path_slug` | 目录路径别名 | string |

### Options

| Option Key | 说明 | 类型 |
|------------|------|------|
| `urllink_path_map` | URL 映射表 | array |
| `urllink_enable_sku_in_url` | 启用 SKU | boolean |

---

## 🔗 相关功能

- **MyTheme SEO**: 自动更新站点地图
- **Tanzanite Settings**: 集成到主插件
- **WordPress 固定链接**: 配合使用

---

## 📚 参考资源

### WordPress 函数
- `url_to_postid()` - URL 转文章 ID
- `get_permalink()` - 获取固定链接
- `wp_redirect()` - 重定向
- `flush_rewrite_rules()` - 刷新重写规则

### 相关文档
- [WordPress 固定链接](https://wordpress.org/support/article/using-permalinks/)
- [301 重定向最佳实践](https://moz.com/learn/seo/redirection)

---

**最后更新**: 2025-11-11  
**维护者**: Tanzanite Team
