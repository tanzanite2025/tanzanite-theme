# Add New Product - 添加新商品

**页面路径**: `admin.php?page=tanzanite-settings-add-product`  
**权限要求**: `tanz_edit_products`  
**REST API**: `POST /wp-json/tanzanite/v1/products`

---

## 📋 功能概述

添加新商品页面提供完整的商品创建功能，支持基本信息、SKU 管理、价格设置、库存管理等。

---

## ✨ 主要功能

### 1. 基本信息

**字段**:
- **商品标题** (title) - 必填
- **商品描述** (content) - 详细描述
- **简短描述** (excerpt) - 摘要
- **特色图片** (featured_image_id) - 主图
- **状态** (status) - publish/draft

---

### 2. SKU 管理

**单规格**:
- SKU 编号
- 价格
- 库存数量

**多规格**:
- 规格组合（颜色、尺寸等）
- 每个规格独立 SKU
- 独立价格和库存

---

### 3. 价格设置

- **常规价格** (price_regular)
- **促销价格** (price_sale)
- **积分奖励** (points_reward)

---

### 4. 分类和标签

- 选择商品分类
- 添加商品标签
- 设置税率模板

---

## 🔌 REST API

```javascript
const response = await $wpApi('/products', {
  method: 'POST',
  body: {
    title: '新商品',
    content: '商品描述',
    price_regular: 999.00,
    stock_qty: 100,
    category_ids: [5],
    tag_ids: [1, 2]
  }
})
```

---

**最后更新**: 2025-11-11  
**维护者**: Tanzanite Team
